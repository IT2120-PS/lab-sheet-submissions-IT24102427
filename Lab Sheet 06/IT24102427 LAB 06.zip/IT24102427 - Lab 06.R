setwd("F:\\Campus Documents\\Y2 S1\\PS LAB\\IT24102427 (PS 6)")
getwd()

#1)
#i. Binomial distribution
#ii.
1-pbinom(46,50,0.85,lower.tail=TRUE)

#2)
#i. Number of calls per hour
#ii. Possion distribution.
#iii. 
dpois(15,12)
