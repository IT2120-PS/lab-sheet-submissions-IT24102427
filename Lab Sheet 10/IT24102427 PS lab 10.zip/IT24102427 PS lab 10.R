setwd("F:\\Campus Documents\\Y2 S1\\PS LAB\\IT24102427 (PS 10)")
getwd()

##Q1)
snack_types <- c("A", "B", "C", "D")
observed <- c(120, 95, 85, 100)

##Q2)
expected_prob <- c(0.25, 0.25, 0.25, 0.25)

##Q3)
test_result <- chisq.test(x = observed, p = expected_prob)


print("Chi-Square Goodness-of-Fit Test Results:")
print(test_result)


print("Expected counts:")
print(test_result$expected)
